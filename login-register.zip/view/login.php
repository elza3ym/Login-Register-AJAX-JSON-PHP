<form action="#" method="post" id="login-form">
    <input type="email" id="email" name="email" class="input-control" placeholder="Email Address" >
    <input type="password" id="password" name="password" class="input-control" placeholder="Password" >
    <button id="login" type="submit" class="btn-submit">Login</button>
</form>
<p class="lead">Don't have account? Please click on register to get one.</p>
<button onclick="register()" class="btn-submit btn-primary">Register</button>
