<? if (isset($_POST['error'])) { echo 'a8a';?>
<div class="alert alert-danger">
    <?=$_POST['error'] ?>
</div>
<? } ?>
