<?php
require_once 'init.php';
    $user = new User();
    $user->logout();

